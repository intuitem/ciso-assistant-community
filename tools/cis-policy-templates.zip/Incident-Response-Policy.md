---
title: "Incident Response Policy"
description: "To ensure that Information Technology (IT) properly identifies, contains, investigates, remedies, reports, and responds to computer security incidents."
document_type: policy
locale: en
provider: CIS
---

|            |                          |                 |
|:-----------|:-------------------------|:----------------|
| Policy \#: | Title:                   | Effective Date: |
| x.xxx      | Incident Response Policy | MM/DD/YY        |

PURPOSE\
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

To ensure that Information Technology (IT) properly identifies, contains, investigates, remedies, reports, and responds to computer security incidents.

REFERENCE\
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

National Institute of Standards and Technology (NIST) Special Publication (SP): NIST SP 800-53a – Incident Response (IR), NIST SP 800-16, NIST SP 800-50, NIST SP 800-61, NIST SP 800-84, NIST SP 800-115

POLICY\
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

This policy is applicable to all departments and users of IT resources and assets.

1.  INCIDENT RESPONSE TRAINING

> The \[entity\] shall:

1.  Provide incident response training to information system users consistent with assigned roles and responsibilities:

<!-- -->

1.  Within \[entity defined time period\] of assuming an incident response role or responsibility.

2.  When required by information system changes, and \[entity defined frequency\] thereafter.

<!-- -->

2.  Incorporate simulated events into incident response training to facilitate effective response by personnel in crisis situations.

3.  Employ automated mechanisms to provide a more thorough and realistic incident response training environment.

<!-- -->

2.  INCIDENT RESPONSE TESTING

> The \[entity\] shall:

1.  Test the incident response capability for the information system \[entity defined frequency\] using \[Assignment: entity defined tests\] to determine the incident response effectiveness and documents the results.

2.  Coordinate incident response testing with entity contacts responsible for related plans such as Business Continuity Plans, Contingency Plans, Disaster Recovery Plans, Continuity of Operations Plans, Crisis Communications Plans, Critical Infrastructure Plans, and Occupant Emergency Plans.

<!-- -->

3.  INCIDENT HANDLING

> The \[Entity\] shall:

1.  Implement an incident handling capability for security incidents that includes preparation, detection and analysis, containment, eradication, and recovery.

2.  Coordinate incident handling activities with contingency planning activities.

3.  Incorporate lessons learned from ongoing incident handling activities into incident response procedures, training, and testing/exercises, and implements the resulting changes accordingly.

<!-- -->

4.  INCIDENT MONITORING

> The \[Entity\] shall:

1.  Employ automated mechanisms to assist in the tracking of security incidents and in the collection and analysis of incident information.

<!-- -->

5.  INCIDENT REPORTING

> The \[Entity\] shall:

1.  Require personnel to report suspected security incidents to the incident response capability within \[entity defined time period\].

2.  Report security incident information to \[entity defined authorities\].

<!-- -->

6.  INCIDENT RESPONSE ASSISTANCE

> The \[entity\] shall:

1.  Provide an incident response support resource, integral to the incident response capability that offers advice and assistance to users of the information system for the handling and reporting of security incidents.

<!-- -->

7.  INCIDENT RESPONSE PLAN

> The \[entity\] shall:

1.  Develop an incident response plan that:

    1.  Provides the entity with a roadmap for implementing its incident response capability.

    2.  Describes the structure of the incident response capability.

    3.  Provides a high-level approach for how the incident response capability fits into the overall entity.

    4.  Meets the unique requirements of the entity, which relate to mission, size, structure, and functions.

    5.  Defines reportable incidents.

    6.  Provides metrics for measuring the incident response capability within the entity.

    7.  Defines the resources and management support needed to effectively maintain and mature an incident response capability.

    8.  Is reviewed and approved by \[entity defined personnel or roles\].

2.  Distribute copies of the incident response plan to \[entity defined incident response personnel (identified by name and/or by role)\].

3.  Review the incident response plan \[entity defined frequency\].

4.  Update the incident response plan to address system changes or problems encountered during plan implementation, execution, or testing.

5.  Communicate incident response plan changes to \[entity defined incident response personnel (identified by name and/or by role)\].

6.  Protect the incident response plan from unauthorized disclosure and modification.

COMPLIANCE

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Employees who violate this policy may be subject to appropriate disciplinary action up to and including discharge as well as both civil and criminal penalties. Non-employees, including, without limitation, contractors, may be subject to termination of contractual agreements, denial of access to IT resources, and other actions as well as both civil and criminal penalties.

POLICY EXCEPTIONS

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Requests for exceptions to this policy shall be reviewed by the Chief Information Security Officer (CISO) and the Chief Information Officer (CIO). Departments requesting exceptions shall provide such requests to the CIO. The request should specifically state the scope of the exception along with justification for granting the exception, the potential impact or risk attendant upon granting the exception, risk mitigation measures to be undertaken by the IT Department, initiatives, actions and a time-frame for achieving the minimum compliance level with the policies set forth herein. The CIO shall review such requests and confer with the requesting department.

RESPONSIBLE DEPARTMENT

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Chief Information Office

DATE ISSUED/DATE REVIEWED\
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

|                |            |
|:---------------|:-----------|
| Date Issued:   | MM/DD/YYYY |
| Date Reviewed: | MM/DD/YYYY |

